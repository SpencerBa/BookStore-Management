/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class DVDs extends ProductClass{

    public DVDs(String name, String type, double price, int quantity, int number) {
        super(name, type, price, quantity, number);
    }
    
}
