/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class Book extends ProductClass{

    public Book(String name, String type, double price, int quantity, int number) {
        super(name, type, price, quantity, number);
    }
    
}
