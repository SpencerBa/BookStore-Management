import java.util.ArrayList;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class Store{
  //  public static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean booksWanted;
        boolean CDsWanted;
        boolean DVDsWanted;
        
        InventoryClass inventory = new InventoryClass();
        ArrayList<ProductClass> storeItems = inventory.getItems();
        ArrayList<ProductClass> cartItems = new ArrayList<>();
        ArrayList<MemberClass> member = new ArrayList<>();
        
        System.out.println("Are you buying or restocking today?");
        System.out.println("Type 'B' for buying or 'R' for restocking");
        String decision = sc.next();
        
        if(decision.equalsIgnoreCase("B")){
        System.out.println("Hello! What is your name?");
        String name = sc.next();
        System.out.println("What is your phone number?");
        String phoneNumber = sc.next();
        System.out.println("How will you be paying today?");
        String paymentType = sc.next();
        System.out.println("Becoming a member costs a small fee of $2 a month!");
        System.out.println("Do you want to be a member? Y for yes N for no");
        String memberShip = sc.next();
            if(memberShip.equalsIgnoreCase("y")){
                MemberClass user = new MemberClass(name,phoneNumber,paymentType,true);
                System.out.println("You are now a member!");
            }
            else{
                MemberClass user = new MemberClass(name,phoneNumber,paymentType,false);
                }
        
        
        
        System.out.println("Here are our items!");
        for(int i=0; i<storeItems.size(); i++){
                //   System.out.println(storeItems.get(i).getName() + "....."+ storeItems.get(i).getType()+".....Item Number: "+ storeItems.get(i).getNumber());
                   System.out.println("Item# "+storeItems.get(i).getNumber()+": is a "+storeItems.get(i).getType()+" named:.... "+storeItems.get(i).getName()+" .... Price: "+storeItems.get(i).getPrice()+". We have "+ storeItems.get(i).getQuantity()+" of this item left.");
               }
        /*
        System.out.println("Enter the Item number you want.");
        int itemNumber=sc.nextInt();
        System.out.println("Amount: ");
        int amount = sc.nextInt();
        storeItems.get(bookNum)
        */
        
        
       System.out.println("Do you want any books? Enter Y for yes or N for no");
       String wantsBooks = sc.next();
            if(wantsBooks.equalsIgnoreCase("y")){
               booksWanted = true;
            }
            else{
                booksWanted = false;
            }
                while(booksWanted == true){
                    System.out.println("What is the Item# of the book you want?");
                    int bookNum =sc.nextInt();
                    System.out.println("How many?: ");
                    int amount = sc.nextInt();
                    ProductClass item = new ProductClass(storeItems.get(bookNum - 1).getName(), storeItems.get(bookNum - 1).getType(), storeItems.get(bookNum - 1).getPrice(), amount, storeItems.get(bookNum - 1).getNumber());
                    cartItems.add(item);
                    //item.removeQuantity(amount);
                    storeItems.get(bookNum - 1).removeQuantity(amount);
                    //System.out.println("Enter '0' when you do not want any more books.");
                    System.out.println("Do you want to add more books? Press 0 to quit adding or 1 to keep adding");
                    int choice=sc.nextInt();

                        if (choice ==0){
                            booksWanted= false;
                        }
                       
                }
                System.out.println("Here is your Cart:");
                double totalBookCost= 0;
                for(int i=0; i<cartItems.size(); i++){
                   System.out.println(cartItems.get(i).getName() + " x" + cartItems.get(i).getQuantity()+" price: "+(cartItems.get(i).getPrice()*cartItems.get(i).getQuantity()));
                   totalBookCost+=cartItems.get(i).getPrice()*cartItems.get(i).getQuantity();
                   
               }  
               
            
               
       System.out.println("Do you want any CDs? Enter Y for yes or N for no" );
       String wantsCDs = sc.next();
            if(wantsCDs.equalsIgnoreCase("y")){
               CDsWanted = true;
            }
            else{
                CDsWanted = false;
            }
                while(CDsWanted == true){
                    System.out.println("What is the Item# of the CD you want?");
                    int CDnum =sc.nextInt();
                    System.out.println("How many?: ");
                    int amount = sc.nextInt();
                    ProductClass item = new ProductClass(storeItems.get(CDnum - 1).getName(), storeItems.get(CDnum - 1).getType(), storeItems.get(CDnum - 1).getPrice(), amount, storeItems.get(CDnum - 1).getNumber());
                    cartItems.add(item);
                    //System.out.println("Enter '0' when you do not want any more books.");
                    storeItems.get(CDnum - 1).removeQuantity(amount);
                    System.out.println("Do you want to add more CDs? Press 0 to quit adding or 1 to keep adding");
                    int choice=sc.nextInt();

                        if (choice ==0){
                            CDsWanted= false;
                        }
                }
                System.out.println("Here is your Cart:");
                double totalCDCost= 0;
                for(int i=0; i<cartItems.size(); i++){
                   System.out.println(cartItems.get(i).getName() + " x" + cartItems.get(i).getQuantity()+" price: "+(cartItems.get(i).getPrice()*cartItems.get(i).getQuantity()));
                   totalCDCost+=cartItems.get(i).getPrice()*cartItems.get(i).getQuantity();
               }
               
       System.out.println("Do you want any DVDs? Enter Y for yes or N for no");
       String wantsDVDs = sc.next();
            if(wantsDVDs.equalsIgnoreCase("y")){
               DVDsWanted = true;
            }
            else{
                DVDsWanted = false;
            }
                while(DVDsWanted == true){
                    System.out.println("What is the Item# of the DVD you want?");
                    int DVDnum =sc.nextInt();
                    System.out.println("How many?: ");
                    int amount = sc.nextInt();
                    ProductClass item = new ProductClass(storeItems.get(DVDnum - 1).getName(), storeItems.get(DVDnum - 1).getType(), storeItems.get(DVDnum - 1).getPrice(), amount, storeItems.get(DVDnum - 1).getNumber());
                    cartItems.add(item);
                    //System.out.println("Enter '0' when you do not want any more books.");
                    storeItems.get(DVDnum - 1).removeQuantity(amount);
                    System.out.println("Do you want to add more CDs? Press 0 to quit adding or 1 to keep adding");
                    int choice=sc.nextInt();

                        if (choice ==0){
                            DVDsWanted= false;
                        }
                }
                System.out.println("Here is your Cart:");
                double totalDVDCost= 0;
                for(int i=0; i<cartItems.size(); i++){
                   System.out.println(cartItems.get(i).getName() + " x" + cartItems.get(i).getQuantity()+" price: "+(cartItems.get(i).getPrice()*cartItems.get(i).getQuantity()));
                   totalDVDCost+=cartItems.get(i).getPrice()*cartItems.get(i).getQuantity();
               }
               double totalPurchaseCost = totalBookCost+totalCDCost+totalDVDCost;
               System.out.println("Your total price comes to: "+totalPurchaseCost);
        }
               
               
        
        
//*************************************************** RESTOCK ITEMS **********************************************************        
            if(decision.equalsIgnoreCase("R")){
               for(int i=0; i<storeItems.size(); i++){
                //   System.out.println(storeItems.get(i).getName() + "....."+ storeItems.get(i).getType()+".....Item Number: "+ storeItems.get(i).getNumber());
                   System.out.println("Item# "+storeItems.get(i).getNumber()+": is a "+storeItems.get(i).getType()+" named:.... "+storeItems.get(i).getName()+" .... Price: "+storeItems.get(i).getPrice()+". We have "+ storeItems.get(i).getQuantity()+" of this item left.");
               }
                   System.out.println("What is the ID of the item you would like to restock?");
                    int restockID = sc.nextInt();
                    System.out.println("How many more would you like to add");
                    int amount =sc.nextInt();
                    inventory.restockProduct(restockID,amount);
                    System.out.println("Here is the new inventory");
                    for(int i=0; i<storeItems.size(); i++){
                //   System.out.println(storeItems.get(i).getName() + "....."+ storeItems.get(i).getType()+".....Item Number: "+ storeItems.get(i).getNumber());
                   System.out.println("Item# "+storeItems.get(i).getNumber()+": is a "+storeItems.get(i).getType()+" named:.... "+storeItems.get(i).getName()+" .... Price: "+storeItems.get(i).getPrice()+". We have "+ storeItems.get(i).getQuantity()+" of this item left.");
               }
                    
                    inventory.inventoryValue();
                    double inventoryValue = inventory.inventoryValue();
                    System.out.println((inventoryValue));
                            
            }
    }
    
}
