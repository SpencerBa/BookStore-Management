
import java.util.ArrayList;
import java.util.Collections;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class InventoryClass implements BookstoreSpecification{
    //private ArrayList<ProductClass> storeItems = new ArrayList<>();
    private ArrayList<ProductClass> items = new ArrayList<>();    

    public InventoryClass() {
        ProductClass book1 = new ProductClass("The Book Theif", "Book", 5.98, 5, 1);
        items.add(book1);
        ProductClass book2 = new ProductClass("Where the Red Fern Grows", "Book", 5.00, 11, 2);
        items.add(book2);
        ProductClass book3 = new ProductClass("The Hunger Games", "Book", 7.13, 3, 3);
        items.add(book3);
        ProductClass book4 = new ProductClass("The Maze Runner", "Book", 4.58, 13, 4);
        items.add(book4);
        ProductClass book5 = new ProductClass("Catcher In the Rye", "Book", 10.99, 9, 5);
        items.add(book5);
        ProductClass book6 = new ProductClass("The Color Purple", "Book", 12.12, 7, 6);    
        items.add(book6);
        ProductClass CD1 = new ProductClass("Def Lepard","CD",5.44,13,7);
        items.add(CD1);
        ProductClass CD2 = new ProductClass("ACDC","CD",7.12,21,8);
        items.add(CD2);
        ProductClass CD3 = new ProductClass("Maroon5","CD",3.11,11,9);
        items.add(CD3);
        ProductClass CD4 = new ProductClass("Post Malone","CD",5.00,17,10);
        items.add(CD4);
        ProductClass CD5 = new ProductClass("One Republic ","CD",4.49,13,11);
        items.add(CD5);
        ProductClass CD6 = new ProductClass("U2","CD",2.19,3,12);
        items.add(CD6);
        ProductClass DVD1= new ProductClass("Grown Ups","DVD",6.79,15,13);
        items.add(DVD1);
        ProductClass DVD2= new ProductClass("Grown Ups2","DVD",6.79,13,14);
        items.add(DVD2);
        ProductClass DVD3= new ProductClass("Get Out","DVD",8.11,19,15);
        items.add(DVD3);
        ProductClass DVD4= new ProductClass("The Maze Runner","DVD",5.79,4,16);
        items.add(DVD4);
        ProductClass DVD5= new ProductClass("Mall Cop","DVD",3.19,20,17);
        items.add(DVD5);
        ProductClass DVD6= new ProductClass("Shutter Island","DVD",13.12,19,18);
        items.add(DVD6);
    }

    // ******************************************** PROJECT 2 ******************************************************
    
    
    public ArrayList<ProductClass> getItems(){
        Collections.sort(items);
        return items;
    }



// used to stor the items by price
    @Override
    public int restockProduct(int productID, int amount) {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
       //int quantity =0;
       int i = 0;
       for (; i < items.size(); i++){
            if(items.get(i).getNumber() == productID){
                items.get(i).addQuantity(amount);
                break;
            }
        }
        return items.get(i).getQuantity();
    }
    
    
    
//takes the total price of the inventory after being restocked
    @Override
    public double inventoryValue() {
        double value =0;
        for (int i=0; i < items.size(); i++){
            value+=items.get(i).getQuantity()*items.get(i).getPrice();
        }
        return value;
    }
    
    // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    
    }
    


