import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class MemberListClass {
    private ArrayList<MemberClass> members = new ArrayList<>();   
   public MemberListClass() {
            MemberClass member1 = new MemberClass("Sam","Card","7049440000",true);
            members.add(member1);
            MemberClass member2 = new MemberClass("Kaitlyn","Card","7046546246",true);
            members.add(member2);
            MemberClass member3 = new MemberClass("Tod","Cash","7042222222",false);
            members.add(member3);
            
            
    }
}
