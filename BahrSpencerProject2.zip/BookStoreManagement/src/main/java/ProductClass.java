/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author spenc
 */
public class ProductClass implements Comparable<ProductClass>{
    private String name;
    private String type;
    private double price;
    private int quantity;
    private int number;
    
    public ProductClass(String name, String type, double price, int quantity, int number){
        this.name = name;
        this.type = type;
        this.price= price;
        this.quantity = quantity;
        this.number=number;
    }
    
    public void setNumber(int number){
        this.number=number;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void removeQuantity(int quantity) {
        this.quantity -= quantity;
    }
   public void addQuantity (int quantity) {
        this.quantity += quantity;
    }
   
    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    public int getNumber(){
        return number;
    }
    

    @Override
    public int compareTo(ProductClass other) {
        if(this.getPrice() > other.getPrice()){
            return  1;
        }
        else if(this.getPrice() < other.getPrice()){
            return -1;
        }
        else{
            return 0;
        }
            
    }

    
    
    
    
}
